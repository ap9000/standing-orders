# Process checks and safe recovery

Failed checks preserve known PIDs/groups. Failed discovery or saving an unidentified child retains the unknown-process safeguard. Supervisor diagnostic failures are separate; actual uncertainty still refuses completion. Diagnostics omit arguments, environments and raw errors.

Passing tests, empty ancestry or service restart alone cannot prove exit. Normal [deployment](../scripts/deploy-browser.mjs) still drains, backs up, checks database compatibility and installs one verified UI/worker build. This narrow legacy repair does not require a Mac restart.

## Inspect and record

The local API is `recoverPreparedObserverGap(store, { profilePath, compilationDirectory, evidenceRoot, mode })`. Start with `mode: "inspect"`; it changes no custody. `"record"` recollects internally. No caller-supplied executable/anchor/serialized success, general CLI, remote endpoint, force-clear flag or migration is added.

The pinned private profile binds positive historical command completion, audited app/runtime/source bytes and logs. Authenticated watch renewal binds a pre-run service identity. Eligibility retains original scope/signer/project/route/grant authority, authentic handoff/executed gate, terminal runs, known spawn exits, and no active work, stop or owned producer. Later reviews do not rewrite the gate or prove exit.

Record saves complete observations and original rows in an exclusive private hash-addressed certificate. One write transaction/savepoint rechecks eligibility and every witness field, updates only eligible unknown rows' exit-observed time, requires normal quiescence, and appends the certificate hash to the ledger atomically. A certificate without the committed ledger entry is observation-only. Collector cleanup waits for owned `close`; a kill request is not exit evidence.

## Limits

Recovery covers direct/ordinary-fork descendants under the audited path and trusted OS/app/toolchain/dependency/configuration/log model. Historical HOME/PATH/npmrc/lifecycle/Git configuration was not sealed. It does not invent a no-delegation attestation or prove absence of malicious/delegated launchd/XPC work.

Ordinary fork/exec inherits coalition membership; the audited path must not request privileged selection or delegate work. Source-coalition privilege itself is unknown. Every non-zombie PID needs readable membership or membership ESRCH followed by fresh identity ESRCH. Permission errors refuse. Counts corroborate identities, never classify unreadable PIDs as foreign. Anchors are revalidated; changed identity/ancestry, tracing and incomplete reads refuse. New PID 1 orphans remain unresolved after exec. Wall birth and 32-bit parent generation are not authority.

XNU adopts a child before publishing its PID and making it runnable. Inventory therefore requires positive original-command/spawn completion and no remaining producer. [Published XNU](https://github.com/apple-oss-distributions/xnu/blob/main/doc/observability/coalitions.md) supports the argument; installed 12377.121.10 is not claimed bitwise equivalent to public 12377.121.6. The release kernel lacks the debug-only PID-list API.

## Evidence and release

[checks.json](../evidence/process-recovery/checks.json) binds source hashes/blobs and complete readable focused receipts. Do not sum overlapping counts. Older unchanged checks, superseded output and failures remain losslessly archived as historical preparation, not current criterion proof. Provenance success is not survivor-assessment or settlement success.

Development base `431603ee9399b86ea32ff76ae8288255558acb25` is not newly verified. Before dispatch, integrate onto the intended verified base and preflight the committed whole-task candidate against that original base. The unchanged native gate and independent review remain required. `REVIEW-VERIFICATION.json`/`REVIEW-CHECK-LOG.txt` bind execution; compare source blobs with `REVIEW-CONTEXT.json` identities, not redacted-text hashes.

Private inventories/logs, credentials and database snapshots stay out of public evidence. Packaging/probes do not settle custody, migrate, dispatch or deploy. Publication and normal update checks remain separate.
